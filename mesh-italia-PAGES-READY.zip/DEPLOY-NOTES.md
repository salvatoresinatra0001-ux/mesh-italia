# mesh-italia — note di distribuzione

Repository: `salvatoresinatra0001-ux/mesh-italia`
URL: https://salvatoresinatra0001-ux.github.io/mesh-italia/

Il sito compilato è sotto `site/`. Il workflow in `.github/workflows/deploy.yml` pubblica tale cartella con GitHub Pages. In Settings → Pages selezionare **GitHub Actions** come fonte del sito. Non sovrascrivere il README esistente.

Versione ricavata dall'archivio fornito dall'utente il 15 ottobre 2026. I link esterni, le informazioni relative ai concerti, il copyright dei contenuti multimediali e le autorizzazioni richiedono valutazione editoriale.
